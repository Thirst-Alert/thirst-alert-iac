      exports.router = (req, res) => {
        res.status(200).send('Managed by Terraform')
      }
